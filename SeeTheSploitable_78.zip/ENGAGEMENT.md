# Engagement: SeeTheSploitable_78

## Metadata
- **Start Date**: 2026-02-04
- **Target**: 192.168.122.236
- **Scope**: Full machine - no restrictions
- **Engagement ID**: d86232899a4e
- **Type**: CTF/Lab Machine
- **Status**: ✅ COMPLETED - ROOT OBTAINED
- **Current Phase**: Post-Exploitation

## Timeline
| Time | Action | Result | Notes |
|------|--------|--------|-------|
| 2026-02-04 10:43 | Engagement started | ✅ Success | Initial setup complete |
| 2026-02-04 10:52 | Nmap scan | ✅ Success | Found ports 139, 445, 8080, 12111 |
| 2026-02-04 10:53 | SMB enumeration | ✅ Success | Found anonymous share with secret.txt |
| 2026-02-04 10:54 | Unlocked port 12111 | ✅ Success | Secret phrase: "apri la porta" |
| 2026-02-04 10:55 | Apache 2.4.50 exposed | ✅ Success | CVE-2021-42013 path traversal |
| 2026-02-04 11:06 | enum4linux | ✅ Success | Found user: it |
| 2026-02-04 11:22 | RCE achieved | ✅ Success | www-data shell via CVE-2021-42013 |
| 2026-02-04 11:23 | Shadow file extracted | ✅ Success | www-data in shadow group! |
| 2026-02-04 11:28 | PwnKit privesc | ✅ Success | ROOT via CVE-2021-4034 |
| 2026-02-04 11:29 | Root flag | 🏆 SUCCESS | Flag: gotme5 |

## Discovered Hosts
| IP | Hostname | OS | Open Ports | Notes |
|----|----------|----|-----------:|-------|
| 192.168.122.236 | debian2022 | Linux Debian | 139, 445, 8080, 12111 | QEMU VM |

## Services Discovered
| Port | Service | Version | Notes |
|------|---------|---------|-------|
| 139/tcp | NetBIOS-SSN | Samba smbd 4.13.13 | Anonymous access |
| 445/tcp | SMB | Samba 4.13.13-Debian | Anonymous share with secret.txt |
| 8080/tcp | HTTP | Python BaseHTTPServer 0.6 | Registration form (closed after unlock) |
| 12111/tcp | HTTP | Apache 2.4.50 | **VULNERABLE** - CVE-2021-42013 |

## Credentials Found
| Username | Password/Hash | Service | Access Level |
|----------|---------------|---------|--------------|
| root | $y$j9T$1BWbie3UmAd5VJAJ9uurh1$sRMrQGr6flctFP1wy0UIjR5j5CJKv0NmfzY3z0sNlxD | shadow (yescrypt) | root |
| it | $y$j9T$X3X4S1wdmu44GDo83eS7o0$/BDL5W.IuTklLr4bWO/6ByF3kRNR9Ep9dnRbth93zMB | shadow (yescrypt) | user |

## Vulnerabilities
| ID | Host | Vulnerability | Severity | Exploited? |
|----|------|---------------|----------|------------|
| CVE-2021-42013 | 192.168.122.236:12111 | Apache Path Traversal/RCE | Critical | ✅ YES |
| CVE-2021-4034 | 192.168.122.236 | PwnKit pkexec LPE | Critical | ✅ YES |

## Attack Path
1. ✅ Nmap scan → Found SMB + custom service on 12111
2. ✅ SMB anonymous access → Found secret.txt ("apri la porta")
3. ✅ Sent secret phrase to port 12111 → Unlocked Apache 2.4.50
4. ✅ CVE-2021-42013 path traversal → Read /etc/passwd, /etc/shadow
5. ✅ CVE-2021-42013 RCE → www-data shell
6. ✅ www-data in shadow group → Extracted password hashes
7. ✅ CVE-2021-4034 PwnKit → ROOT access
8. 🏆 Root flag obtained: gotme5

## Flags/Objectives
| Flag | Value | Location | Method |
|------|-------|----------|--------|
| Root Flag | gotme5 | /root/ans | PwnKit privesc |

## Next Steps
- [x] ~~Run initial nmap scan~~
- [x] ~~Identify services and versions~~
- [x] ~~Research vulnerabilities~~
- [x] ~~Exploit and escalate privileges~~
- [x] ~~Capture root flag~~

## Lessons Learned
- Secret phrases for CTFs often hidden in SMB shares
- Apache 2.4.50 is vulnerable to CVE-2021-42013 (path traversal + RCE)
- Misconfigured www-data in shadow group = instant hash extraction
- pkexec 0.105 vulnerable to PwnKit (CVE-2021-4034)

